class_name CollisionResolver
extends RefCounted


const EPSILON: float = 0.00001
const MIN_SPEED_RATIO: float = 0.01

const AXIS_X: int = 0
const AXIS_Y: int = 1


class Candidate:
	var position: Vector2
	var keepSlide: bool


var _navigationService: NavigationService
var _group: CollisionGroup
var _priorityByUnitId: Dictionary = {}


func _init(
	navigationService: NavigationService
) -> void:
	_navigationService = navigationService


func Resolve(
	group: CollisionGroup,
) -> bool:
	_group = group
	_priorityByUnitId.clear()

	var orderedAgents: Array = group.agents.duplicate()

	orderedAgents.sort_custom(
		func(
			first: CollisionGroup.AgentData,
			second: CollisionGroup.AgentData
		) -> bool:
			return _ComparePriority(
				first,
				second
			)
	)

	for index: int in range(
		orderedAgents.size()
	):
		var data: CollisionGroup.AgentData = (
			orderedAgents[index]
		)

		_priorityByUnitId[
			data.agent.unitId
		] = index

	_InitializeIdleRelations()

	var states: Dictionary = {}
	var reservedPositions: Dictionary = {}

	for data: CollisionGroup.AgentData in orderedAgents:
		states[data.agent.unitId] = 0

	for data: CollisionGroup.AgentData in orderedAgents:
		if not _ReserveAgent(
			data,
			states,
			reservedPositions
		):
			_ReserveStopAgent(
				data,
				states,
				reservedPositions
			)

	return true


func _ReserveAgent(
	data: CollisionGroup.AgentData,
	states: Dictionary,
	reservedPositions: Dictionary
) -> bool:
	var unitId: int = data.agent.unitId
	var state: int = int(
		states.get(
			unitId,
			0
		)
	)

	if state == 2:
		return true

	if state == 1:
		return false

	states[unitId] = 1

	if data.idle:
		data.nextPosition = data.startPosition
		reservedPositions[unitId] = data.nextPosition
		states[unitId] = 2
		return true

	var blockers: Array = _FindBlockers(
		data,
		data.desiredPosition,
		states,
		reservedPositions
	)

	if (
		_HasPersistentSlide(data)
		and not _HasNewIdle(data)
	):
		var persistentCandidates: Array[Candidate] = (
			_BuildPersistentCandidates(
				data,
				reservedPositions,
				blockers
			)
		)

		if _TryReserveCandidates(
			data,
			persistentCandidates,
			states,
			reservedPositions
		):
			return true

	blockers = _FindBlockers(
		data,
		data.desiredPosition,
		states,
		reservedPositions
	)

	var generalCandidates: Array[Candidate] = (
		_BuildGeneralCandidates(
			data,
			reservedPositions,
			blockers
		)
	)

	if _TryReserveCandidates(
		data,
		generalCandidates,
		states,
		reservedPositions
	):
		return true

	states[unitId] = 0

	return false


func _TryReserveCandidates(
	data: CollisionGroup.AgentData,
	candidates: Array[Candidate],
	states: Dictionary,
	reservedPositions: Dictionary
) -> bool:
	for candidate: Candidate in candidates:
		if not _ReserveBlockers(
			data,
			candidate.position,
			states,
			reservedPositions
		):
			continue

		if not _CandidateClear(
			data,
			candidate.position,
			states,
			reservedPositions
		):
			continue

		data.nextPosition = candidate.position

		_ApplyCandidateState(
			data,
			candidate
		)

		reservedPositions[data.agent.unitId] = data.nextPosition
		states[data.agent.unitId] = 2

		return true

	return false


func _ReserveStopAgent(
	data: CollisionGroup.AgentData,
	states: Dictionary,
	reservedPositions: Dictionary
) -> void:
	var unitId: int = data.agent.unitId

	data.nextPosition = data.startPosition

	_ApplyCandidateState(
		data,
		_StopCandidate(data)
	)

	reservedPositions[unitId] = data.nextPosition
	states[unitId] = 2


func _ReserveBlockers(
	data: CollisionGroup.AgentData,
	position: Vector2,
	states: Dictionary,
	reservedPositions: Dictionary
) -> bool:
	var blockers: Array = _FindBlockers(
		data,
		position,
		states,
		reservedPositions
	)

	for blocker: CollisionGroup.AgentData in blockers:
		var blockerId: int = blocker.agent.unitId
		var blockerState: int = int(
			states.get(
				blockerId,
				0
			)
		)

		if reservedPositions.has(blockerId):
			continue

		if blockerState == 1:
			continue

		if blockerState != 0:
			continue

		if not _ReserveAgent(
			blocker,
			states,
			reservedPositions
		):
			_ReserveStopAgent(
				blocker,
				states,
				reservedPositions
			)

	return true


func _FindBlockers(
	data: CollisionGroup.AgentData,
	position: Vector2,
	states: Dictionary,
	reservedPositions: Dictionary
) -> Array:
	var blockers: Array = []

	for other: CollisionGroup.AgentData in _group.agents:
		var otherId: int = other.agent.unitId

		if otherId == data.agent.unitId:
			continue

		var referencePosition: Vector2

		if reservedPositions.has(otherId):
			referencePosition = reservedPositions[otherId]
		else:
			referencePosition = other.startPosition

		if not _Overlap(
			position,
			data.halfSize,
			referencePosition,
			other.halfSize
		):
			continue

		blockers.append(other)

	blockers.sort_custom(
		func(
			first: CollisionGroup.AgentData,
			second: CollisionGroup.AgentData
		) -> bool:
			return int(
				_priorityByUnitId[
					first.agent.unitId
				]
			) < int(
				_priorityByUnitId[
					second.agent.unitId
				]
			)
	)

	return blockers


func _BuildCandidates(
	data: CollisionGroup.AgentData,
	reservedPositions: Dictionary,
	blockers: Array
) -> Array[Candidate]:
	var result: Array[Candidate] = []

	if (
		_HasPersistentSlide(data)
		and not _HasNewIdle(data)
	):
		var persistentCandidates: Array[Candidate] = (
			_BuildPersistentCandidates(
				data,
				reservedPositions,
				blockers
			)
		)

		for candidate: Candidate in persistentCandidates:
			result.append(candidate)

	var generalCandidates: Array[Candidate] = (
		_BuildGeneralCandidates(
			data,
			reservedPositions,
			blockers
		)
	)

	for candidate: Candidate in generalCandidates:
		result.append(candidate)

	return result

func _BuildGeneralCandidates(
	data: CollisionGroup.AgentData,
	reservedPositions: Dictionary,
	blockers: Array
) -> Array[Candidate]:
	var result: Array[Candidate] = []

	result.append(
		_KeepCandidate(data)
	)

	var desiredDirection: Vector2 = (
		data.desiredDelta.normalized()
	)

	if desiredDirection.length_squared() > EPSILON:
		var slowCandidate: Candidate = (
			_BuildSlowCandidate(
				data,
				desiredDirection,
				data.desiredDelta.length(),
				false,
				reservedPositions
			)
		)

		if slowCandidate != null:
			result.append(
				slowCandidate
			)

	if not blockers.is_empty():
		var axisCandidates: Array[Candidate] = (
			_BuildAxisCandidates(
				data,
				blockers,
				reservedPositions
			)
		)

		for candidate: Candidate in axisCandidates:
			result.append(candidate)

	result.append(
		_StopCandidate(data)
	)

	return result


func _BuildPersistentCandidates(
	data: CollisionGroup.AgentData,
	reservedPositions: Dictionary,
	blockers: Array
) -> Array[Candidate]:
	var result: Array[Candidate] = []

	if data.slideDirection.length_squared() <= EPSILON:
		return result

	var direction: Vector2 = data.slideDirection.normalized()

	var persistentCandidate: Candidate = (
		_BuildPersistentCandidate(data)
	)

	if persistentCandidate != null:
		result.append(persistentCandidate)

	var persistentSlowCandidate: Candidate = (
		_BuildSlowCandidate(
			data,
			direction,
			data.speed,
			true,
			reservedPositions
		)
	)

	if persistentSlowCandidate != null:
		result.append(persistentSlowCandidate)

	var turns: Array[Vector2] = [
		Vector2(
			-direction.y,
			direction.x
		),
		Vector2(
			direction.y,
			-direction.x
		)
	]

	turns.sort_custom(
		func(
			first: Vector2,
			second: Vector2
		) -> bool:
			return _DirectionLoss(
				data,
				first
			) < _DirectionLoss(
				data,
				second
			)
	)

	for turnDirection: Vector2 in turns:
		var turnCandidate: Candidate = (
			_BuildMoveCandidate(
				data,
				turnDirection,
				data.speed,
				true
			)
		)

		if turnCandidate != null:
			result.append(turnCandidate)

		var turnSlowCandidate: Candidate = (
			_BuildSlowCandidate(
				data,
				turnDirection,
				data.speed,
				true,
				reservedPositions
			)
		)

		if turnSlowCandidate != null:
			result.append(turnSlowCandidate)

	var hasMovingBlocker: bool = false

	if persistentCandidate != null:
		var persistentBlockers: Array = _FindBlockers(
			data,
			persistentCandidate.position,
			{},
			reservedPositions
		)

		hasMovingBlocker = _HasMovingBlocker(
			persistentBlockers
		)

	if (
		not hasMovingBlocker
		and persistentSlowCandidate != null
	):
		var persistentSlowBlockers: Array = _FindBlockers(
			data,
			persistentSlowCandidate.position,
			{},
			reservedPositions
		)

		hasMovingBlocker = _HasMovingBlocker(
			persistentSlowBlockers
		)

	if hasMovingBlocker:
		var reverseCandidate: Candidate = (
			_BuildMoveCandidate(
				data,
				-direction,
				data.speed,
				true
			)
		)

		if reverseCandidate != null:
			result.append(reverseCandidate)

		var reverseSlowCandidate: Candidate = (
			_BuildSlowCandidate(
				data,
				-direction,
				data.speed,
				true,
				reservedPositions
			)
		)

		if reverseSlowCandidate != null:
			result.append(reverseSlowCandidate)

	return result


func _BuildPersistentCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	if data.slideDirection.length_squared() <= EPSILON:
		return null

	return _BuildMoveCandidate(
		data,
		data.slideDirection,
		data.speed,
		true
	)


func _BuildPersistentMoveCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2
) -> Candidate:
	if direction.length_squared() <= EPSILON:
		return null

	return _BuildMoveCandidate(
		data,
		direction,
		data.speed,
		true
	)


func _HasMovingBlocker(
	blockers: Array
) -> bool:
	for blocker: CollisionGroup.AgentData in blockers:
		if not blocker.idle:
			return true

	return false


func _BuildSlowCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2,
	distance: float,
	keepSlide: bool,
	reservedPositions: Dictionary
) -> Candidate:
	if direction.length_squared() <= EPSILON:
		return null

	if distance <= EPSILON:
		return null

	var moveDirection: Vector2 = (
		direction.normalized()
	)

	var maxDistance: float = distance

	for other: CollisionGroup.AgentData in _group.agents:
		var otherId: int = other.agent.unitId

		if otherId == data.agent.unitId:
			continue

		if not reservedPositions.has(otherId):
			continue

		var referencePosition: Vector2 = (
			reservedPositions[otherId]
		)

		var hitDistance: float = (
			_RayHitDistance(
				data.startPosition,
				moveDirection,
				referencePosition,
				float(
					data.halfSize
					+ other.halfSize
				)
			)
		)

		if is_inf(hitDistance):
			continue

		if hitDistance <= EPSILON:
			return null

		maxDistance = minf(
			maxDistance,
			hitDistance
		)

	if maxDistance < (
		distance * MIN_SPEED_RATIO
	):
		return null

	return _BuildMoveCandidate(
		data,
		moveDirection,
		maxDistance,
		keepSlide
	)


func _BuildAxisCandidates(
	data: CollisionGroup.AgentData,
	blockers: Array,
	reservedPositions: Dictionary
) -> Array[Candidate]:
	var result: Array[Candidate] = []

	var hasXAxisConstraint: bool = false
	var hasYAxisConstraint: bool = false

	for blocker: CollisionGroup.AgentData in blockers:
		var blockedAxis: int = _GetBlockedAxis(
			data,
			blocker,
			reservedPositions
		)

		if blockedAxis == AXIS_X:
			hasXAxisConstraint = true
		else:
			hasYAxisConstraint = true

	if (
		hasXAxisConstraint
		and not hasYAxisConstraint
	):
		var ySign: float = signf(
			data.desiredDelta.y
		)

		if absf(ySign) <= EPSILON:
			ySign = 1.0

		result.append(
			_AxisCandidate(
				data,
				Vector2(
					0.0,
					ySign
				)
			)
		)

		result.append(
			_AxisCandidate(
				data,
				Vector2(
					0.0,
					-ySign
				)
			)
		)

		return result

	if (
		hasYAxisConstraint
		and not hasXAxisConstraint
	):
		var xSign: float = signf(
			data.desiredDelta.x
		)

		if absf(xSign) <= EPSILON:
			xSign = 1.0

		result.append(
			_AxisCandidate(
				data,
				Vector2(
					xSign,
					0.0
				)
			)
		)

		result.append(
			_AxisCandidate(
				data,
				Vector2(
					-xSign,
					0.0
				)
			)
		)

		return result

	var directions: Array[Vector2] = [
		Vector2.RIGHT,
		Vector2.LEFT,
		Vector2.UP,
		Vector2.DOWN
	]

	directions.sort_custom(
		func(
			first: Vector2,
			second: Vector2
		) -> bool:
			return _DirectionLoss(
				data,
				first
			) < _DirectionLoss(
				data,
				second
			)
	)

	for direction: Vector2 in directions:
		result.append(
			_AxisCandidate(
				data,
				direction
			)
		)

	return result


func _GetBlockedAxis(
	data: CollisionGroup.AgentData,
	blocker: CollisionGroup.AgentData,
	reservedPositions: Dictionary
) -> int:
	var blockerPosition: Vector2

	if reservedPositions.has(
		blocker.agent.unitId
	):
		blockerPosition = reservedPositions[
			blocker.agent.unitId
		]
	else:
		blockerPosition = blocker.startPosition

	var relative: Vector2 = (
		blockerPosition
		- data.startPosition
	)

	var x: float = absf(relative.x)
	var y: float = absf(relative.y)

	if x > y:
		return AXIS_X

	if y > x:
		return AXIS_Y

	if absf(data.desiredDelta.x) >= absf(
		data.desiredDelta.y
	):
		return AXIS_X

	return AXIS_Y


func _AxisCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2
) -> Candidate:
	return _BuildMoveCandidate(
		data,
		direction,
		data.speed,
		not data.currentIdleIds.is_empty()
	)


func _BuildMoveCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2,
	distance: float,
	keepSlide: bool
) -> Candidate:
	if direction.length_squared() <= EPSILON:
		return null

	if distance <= EPSILON:
		return null

	var candidate: Candidate = Candidate.new()

	candidate.position = (
		data.startPosition
		+ direction.normalized()
		* distance
	)

	candidate.keepSlide = keepSlide

	return candidate


func _KeepCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = data.desiredPosition
	candidate.keepSlide = (
		data.slideDirection.length_squared()
		> EPSILON
	)

	return candidate


func _StopCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = data.startPosition
	candidate.keepSlide = false

	return candidate


func _ApplyCandidateState(
	data: CollisionGroup.AgentData,
	candidate: Candidate
) -> void:
	if not candidate.keepSlide:
		if data.currentIdleIds.is_empty():
			data.slideDirection = Vector2.ZERO

		return

	var delta: Vector2 = (
		candidate.position
		- data.startPosition
	)

	if delta.length_squared() <= EPSILON:
		return

	data.slideDirection = delta.normalized()


func _InitializeIdleRelations() -> void:
	for data: CollisionGroup.AgentData in _group.agents:
		data.currentIdleIds.clear()

	for pair: Vector2i in _group.collisions:
		var first: CollisionGroup.AgentData = (
			_FindAgent(pair.x)
		)

		var second: CollisionGroup.AgentData = (
			_FindAgent(pair.y)
		)

		if first == null or second == null:
			continue

		if first.idle and not second.idle:
			second.currentIdleIds.append(
				first.agent.unitId
			)

		elif second.idle and not first.idle:
			first.currentIdleIds.append(
				second.agent.unitId
			)


func _HasPersistentSlide(
	data: CollisionGroup.AgentData
) -> bool:
	return (
		data.slideDirection.length_squared()
		> EPSILON
	)


func _HasNewIdle(
	data: CollisionGroup.AgentData
) -> bool:
	for idleId in data.currentIdleIds:
		if not data.slideIdleIds.has(idleId):
			return true

	return false


func _CandidateClear(
	data: CollisionGroup.AgentData,
	position: Vector2,
	states: Dictionary,
	reservedPositions: Dictionary
) -> bool:
	if not _StaticClear(
		data,
		position
	):
		return false

	for other: CollisionGroup.AgentData in _group.agents:
		var otherId: int = other.agent.unitId

		if otherId == data.agent.unitId:
			continue

		var referencePosition: Vector2

		if reservedPositions.has(otherId):
			referencePosition = reservedPositions[otherId]
		else:
			referencePosition = other.startPosition

		if _Overlap(
			position,
			data.halfSize,
			referencePosition,
			other.halfSize
		):
			return false

	return true


func _ComparePriority(
	first: CollisionGroup.AgentData,
	second: CollisionGroup.AgentData
) -> bool:
	if first.idle != second.idle:
		return first.idle

	var firstDistance: float = (
		first.startPosition.distance_squared_to(
			first.agent.moveTarget
		)
	)

	var secondDistance: float = (
		second.startPosition.distance_squared_to(
			second.agent.moveTarget
		)
	)

	if not is_equal_approx(
		firstDistance,
		secondDistance
	):
		return firstDistance < secondDistance

	return (
		first.agent.unitId
		< second.agent.unitId
	)


func _StaticClear(
	data: CollisionGroup.AgentData,
	position: Vector2
) -> bool:
	if _navigationService == null:
		return true

	return _navigationService.SegmentClear(
		data.startPosition,
		position,
		data.halfSize
	)


func _RayHitDistance(
	origin: Vector2,
	direction: Vector2,
	center: Vector2,
	halfSize: float
) -> float:
	var relative: Vector2 = center - origin
	var enter: float = -INF
	var exit: float = INF

	if absf(direction.x) <= EPSILON:
		if absf(relative.x) > halfSize:
			return INF
	else:
		var tx1: float = (
			relative.x - halfSize
		) / direction.x

		var tx2: float = (
			relative.x + halfSize
		) / direction.x

		var tempX: float

		if tx1 > tx2:
			tempX = tx1
			tx1 = tx2
			tx2 = tempX

		enter = maxf(
			enter,
			tx1
		)

		exit = minf(
			exit,
			tx2
		)

	if absf(direction.y) <= EPSILON:
		if absf(relative.y) > halfSize:
			return INF
	else:
		var ty1: float = (
			relative.y - halfSize
		) / direction.y

		var ty2: float = (
			relative.y + halfSize
		) / direction.y

		var tempY: float

		if ty1 > ty2:
			tempY = ty2
			ty2 = ty1
			ty1 = tempY

		enter = maxf(
			enter,
			ty1
		)

		exit = minf(
			exit,
			ty2
		)

	if enter > exit:
		return INF

	if exit < 0.0:
		return INF

	return maxf(
		enter,
		0.0
	)


func _DirectionLoss(
	data: CollisionGroup.AgentData,
	direction: Vector2
) -> float:
	if data.desiredDelta.length_squared() <= EPSILON:
		return 1.0

	return 1.0 - data.desiredDelta.normalized().dot(
		direction.normalized()
	)


func _FindAgent(
	unitId: int
) -> CollisionGroup.AgentData:
	for data: CollisionGroup.AgentData in _group.agents:
		if data.agent.unitId == unitId:
			return data

	return null


func _Overlap(
	firstPosition: Vector2,
	firstHalfSize: int,
	secondPosition: Vector2,
	secondHalfSize: int
) -> bool:
	var size: float = float(
		firstHalfSize
		+ secondHalfSize
	)

	return (
		absf(
			firstPosition.x
			- secondPosition.x
		) < size
		and absf(
			firstPosition.y
			- secondPosition.y
		) < size
	)

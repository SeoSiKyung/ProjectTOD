class_name CollisionResolver
extends RefCounted


const EPSILON: float = 0.00001
const MIN_SPEED_RATIO: float = 0.1
const SLOW_STEP_COUNT: int = 10

const AXIS_X: int = 0
const AXIS_Y: int = 1

const MODE_KEEP: int = 0
const MODE_SLOW: int = 1
const MODE_AXIS: int = 2
const MODE_SLIDE: int = 3
const MODE_STOP: int = 4


class Candidate:
	var position: Vector2
	var mode: int
	var speedRatio: float
	var directionLoss: float
	var keepSlide: bool


var _navigationService: NavigationService
var _group: CollisionGroup
var _fixedDelta: float


func _init(navigationService: NavigationService) -> void:
	_navigationService = navigationService


func Resolve(
	group: CollisionGroup,
	fixedDelta: float
) -> bool:
	_group = group
	_fixedDelta = fixedDelta

	var pausedIds: Array[int] = []
	var maxIterations: int = max(
		8,
		group.agents.size() * 8
	)

	for _iteration: int in range(maxIterations):
		var currentCollisions: Array[Vector2i] = (
			_CollectCurrentCollisions()
		)

		if currentCollisions.is_empty():
			return true

		_UpdateIdleRelations(
			currentCollisions
		)

		var changed: bool = false

		for pair: Vector2i in currentCollisions:
			var first: CollisionGroup.AgentData = (
				_FindAgent(pair.x)
			)

			var second: CollisionGroup.AgentData = (
				_FindAgent(pair.y)
			)

			if first == null or second == null:
				continue

			if not _Overlap(
				first.nextPosition,
				first.halfSize,
				second.nextPosition,
				second.halfSize
			):
				continue

			var result: Array = _ResolvePair(
				first,
				second
			)

			if result.is_empty():
				continue

			first.nextPosition = result[0].position
			second.nextPosition = result[1].position

			_ApplySlideState(
				first,
				result[0]
			)

			_ApplySlideState(
				second,
				result[1]
			)

			changed = true

		if changed:
			continue

		if group.agents.size() < 3:
			return false

		var pausedAgent: CollisionGroup.AgentData = (
			_PauseOneAgent(pausedIds)
		)

		if pausedAgent == null:
			return false

		pausedIds.append(
			pausedAgent.agent.unitId
		)

	return _CollectCurrentCollisions().is_empty()


func _CollectCurrentCollisions() -> Array[Vector2i]:
	var result: Array[Vector2i] = []

	for firstIndex: int in range(
		_group.agents.size()
	):
		var first: CollisionGroup.AgentData = (
			_group.agents[firstIndex]
		)

		for secondIndex: int in range(
			firstIndex + 1,
			_group.agents.size()
		):
			var second: CollisionGroup.AgentData = (
				_group.agents[secondIndex]
			)

			if not _Overlap(
				first.nextPosition,
				first.halfSize,
				second.nextPosition,
				second.halfSize
			):
				continue

			result.append(
				Vector2i(
					first.agent.unitId,
					second.agent.unitId
				)
			)

	return result


func _ResolvePair(
	first: CollisionGroup.AgentData,
	second: CollisionGroup.AgentData
) -> Array:
	if first.idle and second.idle:
		return []

	if first.idle:
		return _ReverseResult(
			_ResolveMovingIdle(
				second,
				first
			)
		)

	if second.idle:
		return _ResolveMovingIdle(
			first,
			second
		)

	return _ResolveGeneralCollision(
		first,
		second
	)


func _ResolveMovingIdle(
	moving: CollisionGroup.AgentData,
	idle: CollisionGroup.AgentData
) -> Array:
	var candidates: Array = _BuildCandidates(
		moving,
		idle
	)

	for candidate: Candidate in candidates:
		if not _PairClear(
			moving,
			candidate.position,
			idle,
			idle.nextPosition
		):
			continue

		return [
			candidate,
			_IdleCandidate(idle)
		]

	return []


func _ResolvePersistentSlide(
	sliding: CollisionGroup.AgentData,
	other: CollisionGroup.AgentData
) -> Array:
	var directions: Array = (
		_GetPersistentSlideDirections(
			sliding.slideDirection
		)
	)

	for direction: Vector2 in directions:
		var slideCandidate: Candidate = _SlideCandidate(
			sliding,
			direction,
			true
		)

		if not _StaticClear(
			sliding,
			slideCandidate.position
		):
			continue

		if _PairClear(
			sliding,
			slideCandidate.position,
			other,
			other.nextPosition
		):
			return [
				slideCandidate,
				_KeepCandidate(other)
			]

	var otherCandidates: Array = (
		_BuildCandidatesWithoutPersistentSlide(
			other
		)
	)

	for direction: Vector2 in directions:
		var slideCandidate: Candidate = _SlideCandidate(
			sliding,
			direction,
			true
		)

		if not _StaticClear(
			sliding,
			slideCandidate.position
		):
			continue

		for candidate: Candidate in otherCandidates:
			if _PairClear(
				sliding,
				slideCandidate.position,
				other,
				candidate.position
			):
				return [
					slideCandidate,
					candidate
				]

	return []


func _ResolveGeneralCollision(
	first: CollisionGroup.AgentData,
	second: CollisionGroup.AgentData
) -> Array:
	var firstCandidates: Array = _BuildCandidates(
		first,
		second
	)

	var secondCandidates: Array = _BuildCandidates(
		second,
		first
	)

	return _FindBestPair(
		first,
		firstCandidates,
		second,
		secondCandidates
	)


func _BuildCandidates(
	data: CollisionGroup.AgentData,
	blocker: CollisionGroup.AgentData
) -> Array:
	var result: Array = []

	if data.idle:
		result.append(
			_IdleCandidate(data)
		)
		return result

	if not data.currentIdleIds.is_empty():
		if (
			_HasPersistentSlide(data)
			and not _HasNewIdle(data)
		):
			result.append(
				_SlideCandidate(
					data,
					data.slideDirection,
					true
				)
			)
			return result

	result.append(
		_KeepCandidate(data)
	)

	var slowCandidates: Array = _BuildSlowCandidates(
		data
	)

	for candidate: Candidate in slowCandidates:
		result.append(candidate)

	var axisCandidates: Array = _BuildAxisCandidates(
		data,
		blocker
	)

	for candidate: Candidate in axisCandidates:
		result.append(candidate)

	var alternateCandidates: Array = (
		_BuildAlternateCandidates(data)
	)

	for candidate: Candidate in alternateCandidates:
		result.append(candidate)

	result.append(
		_StopCandidate(data)
	)

	return result


func _BuildCandidatesWithoutPersistentSlide(
	data: CollisionGroup.AgentData
) -> Array:
	var result: Array = []

	if data.idle:
		result.append(
			_IdleCandidate(data)
		)
		return result

	result.append(
		_KeepCandidate(data)
	)

	var slowCandidates: Array = _BuildSlowCandidates(
		data
	)

	for candidate: Candidate in slowCandidates:
		result.append(candidate)

	var axisCandidates: Array = (
		_BuildAxisCandidatesWithoutBlocker(data)
	)

	for candidate: Candidate in axisCandidates:
		result.append(candidate)

	var alternateCandidates: Array = (
		_BuildAlternateCandidates(data)
	)

	for candidate: Candidate in alternateCandidates:
		result.append(candidate)

	result.append(
		_StopCandidate(data)
	)

	return result


func _BuildSlowCandidates(
	data: CollisionGroup.AgentData
) -> Array:
	var result: Array = []

	if data.desiredDelta.length_squared() <= EPSILON:
		return result

	var direction: Vector2 = (
		data.desiredDelta.normalized()
	)

	var distance: float = data.desiredDelta.length()

	for step: int in range(
		SLOW_STEP_COUNT - 1,
		0,
		-1
	):
		var ratio: float = (
			float(step)
			/ float(SLOW_STEP_COUNT)
		)

		ratio = maxf(
			ratio,
			MIN_SPEED_RATIO
		)

		var candidate: Candidate = Candidate.new()

		candidate.position = (
			data.startPosition
			+ direction
			* distance
			* ratio
		)

		candidate.mode = MODE_SLOW
		candidate.speedRatio = ratio
		candidate.directionLoss = 0.0
		candidate.keepSlide = false

		result.append(candidate)

	return result


func _BuildAxisCandidates(
	data: CollisionGroup.AgentData,
	blocker: CollisionGroup.AgentData
) -> Array:
	var result: Array = []

	var blockedAxis: int = _GetBlockedAxis(
		data,
		blocker
	)

	var freeAxis: int = (
		AXIS_Y
		if blockedAxis == AXIS_X
		else AXIS_X
	)

	var direction: Vector2 = _GetFreeAxisDirection(
		data,
		freeAxis
	)

	if direction.length_squared() <= EPSILON:
		return result

	var first: Candidate = _AxisCandidate(
		data,
		direction
	)

	var second: Candidate = _AxisCandidate(
		data,
		-direction
	)

	if _StaticClear(
		data,
		first.position
	):
		result.append(first)

	if _StaticClear(
		data,
		second.position
	):
		result.append(second)

	return result


func _BuildAxisCandidatesWithoutBlocker(
	data: CollisionGroup.AgentData
) -> Array:
	var result: Array = []

	if data.desiredDelta.length_squared() <= EPSILON:
		return result

	var firstDirection: Vector2

	if absf(data.desiredDelta.x) >= absf(
		data.desiredDelta.y
	):
		firstDirection = Vector2(
			0.0,
			signf(data.desiredDelta.y)
		)

		if firstDirection.length_squared() <= EPSILON:
			firstDirection = Vector2.UP
	else:
		firstDirection = Vector2(
			signf(data.desiredDelta.x),
			0.0
		)

	if firstDirection.length_squared() <= EPSILON:
		return result

	var first: Candidate = _AxisCandidate(
		data,
		firstDirection
	)

	var second: Candidate = _AxisCandidate(
		data,
		-firstDirection
	)

	result.append(first)
	result.append(second)

	return result


func _BuildAlternateCandidates(
	data: CollisionGroup.AgentData
) -> Array[Candidate]:
	var result: Array[Candidate] = []

	var directions: Array[Vector2] = [
		Vector2.RIGHT,
		Vector2.LEFT,
		Vector2.UP,
		Vector2.DOWN
	]

	directions.sort_custom(
		func(
			first: Vector2,
			second: Vector2
		) -> bool:
			return _DirectionLoss(
				data,
				first
			) < _DirectionLoss(
				data,
				second
			)
	)

	var keepSlide: bool = (
		not data.currentIdleIds.is_empty()
	)

	for direction: Vector2 in directions:
		result.append(
			_SlideCandidate(
				data,
				direction,
				keepSlide
			)
		)

	return result


func _AxisCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = (
		data.startPosition
		+ direction.normalized()
		* data.speed
		* _fixedDelta
	)

	candidate.mode = MODE_AXIS
	candidate.speedRatio = 1.0
	candidate.directionLoss = _DirectionLoss(
		data,
		direction
	)

	candidate.keepSlide = (
		not data.currentIdleIds.is_empty()
	)

	return candidate


func _SlideCandidate(
	data: CollisionGroup.AgentData,
	direction: Vector2,
	keepSlide: bool
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = (
		data.startPosition
		+ direction.normalized()
		* data.speed
		* _fixedDelta
	)

	candidate.mode = MODE_SLIDE
	candidate.speedRatio = 1.0
	candidate.directionLoss = _DirectionLoss(
		data,
		direction
	)

	candidate.keepSlide = keepSlide

	return candidate


func _KeepCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = data.desiredPosition
	candidate.mode = MODE_KEEP
	candidate.speedRatio = _SpeedRatio(
		data,
		candidate.position
	)

	candidate.directionLoss = 0.0

	candidate.keepSlide = (
		data.slideDirection.length_squared()
		> EPSILON
	)

	return candidate


func _IdleCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = data.nextPosition
	candidate.mode = MODE_KEEP
	candidate.speedRatio = 0.0
	candidate.directionLoss = 0.0
	candidate.keepSlide = false

	return candidate


func _StopCandidate(
	data: CollisionGroup.AgentData
) -> Candidate:
	var candidate: Candidate = Candidate.new()

	candidate.position = data.startPosition
	candidate.mode = MODE_STOP
	candidate.speedRatio = 0.0
	candidate.directionLoss = 1.0
	candidate.keepSlide = false

	return candidate


func _FindBestPair(
	first: CollisionGroup.AgentData,
	firstCandidates: Array,
	second: CollisionGroup.AgentData,
	secondCandidates: Array
) -> Array:
	var best: Array = []
	var bestStage: int = 999
	var bestSpeed: float = -1.0
	var bestLoss: float = INF

	for firstCandidate: Candidate in firstCandidates:
		for secondCandidate: Candidate in secondCandidates:
			if not _PairClear(
				first,
				firstCandidate.position,
				second,
				secondCandidate.position
			):
				continue

			var stage: int = maxi(
				firstCandidate.mode,
				secondCandidate.mode
			)

			var speed: float = (
				firstCandidate.speedRatio
				+ secondCandidate.speedRatio
			)

			var loss: float = (
				firstCandidate.directionLoss
				+ secondCandidate.directionLoss
			)

			if stage < bestStage:
				best = [
					firstCandidate,
					secondCandidate
				]

				bestStage = stage
				bestSpeed = speed
				bestLoss = loss
				continue

			if stage > bestStage:
				continue

			if speed > bestSpeed:
				best = [
					firstCandidate,
					secondCandidate
				]

				bestSpeed = speed
				bestLoss = loss
				continue

			if is_equal_approx(
				speed,
				bestSpeed
			) and loss < bestLoss:
				best = [
					firstCandidate,
					secondCandidate
				]

				bestLoss = loss

	return best


func _PairClear(
	first: CollisionGroup.AgentData,
	firstPosition: Vector2,
	second: CollisionGroup.AgentData,
	secondPosition: Vector2
) -> bool:
	if not _StaticClear(
		first,
		firstPosition
	):
		return false

	if not _StaticClear(
		second,
		secondPosition
	):
		return false

	if _Overlap(
		firstPosition,
		first.halfSize,
		secondPosition,
		second.halfSize
	):
		return false

	return true


func _StaticClear(
	data: CollisionGroup.AgentData,
	position: Vector2
) -> bool:
	if _navigationService == null:
		return true

	return _navigationService.SegmentClear(
		data.startPosition,
		position,
		data.halfSize
	)


func _GetBlockedAxis(
	data: CollisionGroup.AgentData,
	blocker: CollisionGroup.AgentData
) -> int:
	var relative: Vector2 = (
		blocker.nextPosition
		- data.nextPosition
	)

	if absf(relative.x) > absf(relative.y):
		return AXIS_X

	if absf(relative.y) > absf(relative.x):
		return AXIS_Y

	if absf(data.desiredDelta.x) >= absf(
		data.desiredDelta.y
	):
		return AXIS_X

	return AXIS_Y


func _GetFreeAxisDirection(
	data: CollisionGroup.AgentData,
	axis: int
) -> Vector2:
	if axis == AXIS_X:
		if absf(data.desiredDelta.x) > EPSILON:
			return Vector2(
				signf(data.desiredDelta.x),
				0.0
			)

		return Vector2.RIGHT

	if absf(data.desiredDelta.y) > EPSILON:
		return Vector2(
			0.0,
			signf(data.desiredDelta.y)
		)

	return Vector2.DOWN


func _HasPersistentSlide(
	data: CollisionGroup.AgentData
) -> bool:
	return data.slideDirection.length_squared() > EPSILON


func _HasNewIdle(
	data: CollisionGroup.AgentData
) -> bool:
	for idleId in data.currentIdleIds:
		if not data.slideIdleIds.has(idleId):
			return true

	return false


func _ApplySlideState(
	data: CollisionGroup.AgentData,
	candidate: Candidate
) -> void:
	if not candidate.keepSlide:
		if data.currentIdleIds.is_empty():
			data.slideDirection = Vector2.ZERO

		return

	var delta: Vector2 = (
		candidate.position
		- data.startPosition
	)

	if delta.length_squared() <= EPSILON:
		return

	data.slideDirection = delta.normalized()


func _SpeedRatio(
	data: CollisionGroup.AgentData,
	position: Vector2
) -> float:
	var desiredDistance: float = data.desiredDelta.length()

	if desiredDistance <= EPSILON:
		return 0.0

	return clampf(
		position.distance_to(
			data.startPosition
		)
		/ desiredDistance,
		0.0,
		1.0
	)


func _DirectionLoss(
	data: CollisionGroup.AgentData,
	direction: Vector2
) -> float:
	if data.desiredDelta.length_squared() <= EPSILON:
		return 1.0

	return 1.0 - data.desiredDelta.normalized().dot(
		direction.normalized()
	)


func _UpdateIdleRelations(
	collisions: Array[Vector2i]
) -> void:
	for data: CollisionGroup.AgentData in _group.agents:
		data.currentIdleIds.clear()

	for pair: Vector2i in collisions:
		var first: CollisionGroup.AgentData = _FindAgent(
			pair.x
		)

		var second: CollisionGroup.AgentData = _FindAgent(
			pair.y
		)

		if first == null or second == null:
			continue

		if first.idle and not second.idle:
			second.currentIdleIds.append(
				first.agent.unitId
			)

		elif second.idle and not first.idle:
			first.currentIdleIds.append(
				second.agent.unitId
			)


func _ReverseResult(
	result: Array
) -> Array:
	if result.is_empty():
		return []

	return [
		result[1],
		result[0]
	]


func _FindAgent(
	unitId: int
) -> CollisionGroup.AgentData:
	for data: CollisionGroup.AgentData in _group.agents:
		if data.agent.unitId == unitId:
			return data

	return null


func _PauseOneAgent(
	pausedIds: Array[int]
) -> CollisionGroup.AgentData:
	var candidateIds: Array[int] = []

	for pair: Vector2i in _group.collisions:
		var first: CollisionGroup.AgentData = _FindAgent(
			pair.x
		)

		var second: CollisionGroup.AgentData = _FindAgent(
			pair.y
		)

		if first == null or second == null:
			continue

		if not _Overlap(
			first.nextPosition,
			first.halfSize,
			second.nextPosition,
			second.halfSize
		):
			continue

		if first.idle and second.idle:
			continue

		if (
			not first.idle
			and not pausedIds.has(first.agent.unitId)
		):
			if not candidateIds.has(
				first.agent.unitId
			):
				candidateIds.append(
					first.agent.unitId
				)

		if (
			not second.idle
			and not pausedIds.has(second.agent.unitId)
		):
			if not candidateIds.has(
				second.agent.unitId
			):
				candidateIds.append(
					second.agent.unitId
				)

	var selected: CollisionGroup.AgentData = null

	for unitId: int in candidateIds:
		var data: CollisionGroup.AgentData = _FindAgent(
			unitId
		)

		if data == null:
			continue

		if selected == null:
			selected = data
			continue

		var selectedDistance: float = (
			selected.desiredDelta.length_squared()
		)

		var currentDistance: float = (
			data.desiredDelta.length_squared()
		)

		if currentDistance < selectedDistance:
			selected = data
			continue

		if is_equal_approx(
			currentDistance,
			selectedDistance
		):
			if data.agent.unitId > selected.agent.unitId:
				selected = data

	if selected == null:
		return null

	selected.nextPosition = selected.startPosition
	selected.desiredPosition = selected.startPosition
	selected.desiredDelta = Vector2.ZERO
	selected.idle = true
	selected.slideDirection = Vector2.ZERO
	selected.currentIdleIds.clear()

	return selected


func _GetPersistentSlideDirections(
	currentDirection: Vector2
) -> Array:
	if currentDirection.length_squared() <= EPSILON:
		return []

	var direction: Vector2 = (
		currentDirection.normalized()
	)

	return [
		direction,
		-direction,
		Vector2(-direction.y, direction.x),
		Vector2(direction.y, -direction.x)
	]


func _Overlap(
	firstPosition: Vector2,
	firstHalfSize: int,
	secondPosition: Vector2,
	secondHalfSize: int
) -> bool:
	var size: float = float(
		firstHalfSize + secondHalfSize
	)

	return (
		absf(
			firstPosition.x - secondPosition.x
		) < size
		and absf(
			firstPosition.y - secondPosition.y
		) < size
	)
